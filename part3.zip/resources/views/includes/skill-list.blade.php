<div class="skills">
  <h3>KEMAMPUAN</h3>

  <h4>Hard Skills</h4>
  <div class="skill-grid">
    <x-skill-card skill="HTML & CSS" level="Advanced" />
    <x-skill-card skill="JavaScript" level="Advanced" />
    <x-skill-card skill="PHP & Laravel" level="Advanced"/>
    <x-skill-card skill="Laravel" level="Basic" />
    <x-skill-card skill="Database Management (MySQL)" level="Advance"/>
  </div>

  <h4>Soft Skills</h4>
  <div class="skill-grid">
    <x-skill-card skill="Analytical Thinking" level="Good" />
    <x-skill-card skill="Teamwork" level="Excellent" />
    <x-skill-card skill="Communication" level="Good" />
    <x-skill-card skill="Time Management" level="Good" />
    <x-skill-card skill="Problem Solving" level="Excellent" />
  </div>
</div>

