@extends('layouts.app')

@section('content')
    <p>ini adalah isi dari home.blade</p>
    <p>Nama saya adalah {{ $nama }}</p>
@endsection