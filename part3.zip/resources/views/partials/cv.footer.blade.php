<footer class="bg-blue-900 text-white text-center py-3 text-sm mt-auto">
  © {{ date('Y') }} Tekno Hosnews. All Rights Reserved.
</footer>
