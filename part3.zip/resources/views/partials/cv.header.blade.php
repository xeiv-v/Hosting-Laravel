<header class="text-center py-3 bg-primary text-white">
  <h2>Curriculum Vitae</h2>
</header>
