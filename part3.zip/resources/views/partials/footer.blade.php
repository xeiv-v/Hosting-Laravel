<footer>
    <h1>INI FOOTER</h1>
</footer>