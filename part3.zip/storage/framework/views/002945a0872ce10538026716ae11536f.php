<div class="hobby">
  <h3>HOBI</h3>
  <ul class="hobby-list">
    <li>Desain Web</li>
    <li>Menulis</li>
    <li>Fotografi</li>
    <li>Mendengarkan Musik</li>
    <li>Membaca Buku</li>
  </ul>
</div>
<?php /**PATH D:\xampp\isi\htdocs\belajar_laravel\resources\views/includes/hobby-list.blade.php ENDPATH**/ ?>