<?php
  switch($level) {
      case 'Expert': $width = '100%'; break;
      case 'Advanced': $width = '85%'; break;
      case 'Intermediate': $width = '85%'; break;
      case 'Basic': $width = '40%'; break;
      default: $width = '50%'; break;
  }
?>

<div class="skill-card">
  <div class="skill-name"><?php echo e($skill); ?></div>
  <div class="skill-level">
    <div class="level-bar">
      <div class="level-fill" style="width: '<?php echo e($width); ?>';"></div>
    </div>
    <span class="level-text"><?php echo e($level); ?></span>
  </div>
</div>
<?php /**PATH D:\xampp\isi\htdocs\belajar_laravel\resources\views/components/skill-card.blade.php ENDPATH**/ ?>