<header class="header">
  <h1>Curriculum Vitae</h1>
</header>
<?php /**PATH D:\xampp\isi\htdocs\belajar_laravel\resources\views/includes/header.blade.php ENDPATH**/ ?>