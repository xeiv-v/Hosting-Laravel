<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'Curriculum Vitae'); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>
</body>
</html>
<?php /**PATH D:\xampp\isi\htdocs\belajar_laravel\resources\views/layouts/cv.blade.php ENDPATH**/ ?>