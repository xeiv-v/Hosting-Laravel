<div class="skills">
  <h3>KEMAMPUAN</h3>

  <h4>Hard Skills</h4>
  <div class="skill-grid">
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'HTML & CSS','level' => 'Advanced']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'HTML & CSS','level' => 'Advanced']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'JavaScript','level' => 'Advanced']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'JavaScript','level' => 'Advanced']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'PHP & Laravel','level' => 'Advanced']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'PHP & Laravel','level' => 'Advanced']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'Laravel','level' => 'Basic']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'Laravel','level' => 'Basic']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'Database Management (MySQL)','level' => 'Advance']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'Database Management (MySQL)','level' => 'Advance']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
  </div>

  <h4>Soft Skills</h4>
  <div class="skill-grid">
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'Analytical Thinking','level' => 'Good']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'Analytical Thinking','level' => 'Good']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'Teamwork','level' => 'Excellent']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'Teamwork','level' => 'Excellent']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'Communication','level' => 'Good']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'Communication','level' => 'Good']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'Time Management','level' => 'Good']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'Time Management','level' => 'Good']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcebc4c60919626cbae8d88c589f7ba40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skill-card','data' => ['skill' => 'Problem Solving','level' => 'Excellent']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skill-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skill' => 'Problem Solving','level' => 'Excellent']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $attributes = $__attributesOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__attributesOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40)): ?>
<?php $component = $__componentOriginalcebc4c60919626cbae8d88c589f7ba40; ?>
<?php unset($__componentOriginalcebc4c60919626cbae8d88c589f7ba40); ?>
<?php endif; ?>
  </div>
</div>

<?php /**PATH D:\xampp\isi\htdocs\belajar_laravel\resources\views/includes/skill-list.blade.php ENDPATH**/ ?>