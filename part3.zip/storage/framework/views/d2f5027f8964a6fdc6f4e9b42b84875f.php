<nav class="navbar">
  <ul>
    <li><a href="#profil">Profil</a></li>
    <li><a href="#pendidikan">Pendidikan</a></li>
    <li><a href="#prestasi">Prestasi</a></li>
  </ul>
</nav>
<?php /**PATH D:\xampp\isi\htdocs\belajar_laravel\resources\views/components/navbar.blade.php ENDPATH**/ ?>