<footer class="footer">
  <p>&copy; 2025 Bagus Riyadi. All Rights Reserved.</p>
</footer>
<?php /**PATH D:\xampp\isi\htdocs\belajar_laravel\resources\views/includes/footer.blade.php ENDPATH**/ ?>